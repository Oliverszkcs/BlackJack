/** Card png from: https://code.google.com/archive/p/vector-playing-cards/downloads   **/

public class Main {

    public static void main(String[] args) throws Exception {
        MenuGUI menu=new MenuGUI();//elindul a menü ahonnan további opciókat érhetünk el
    }
}